# PocketTracker 3 R6 for Anbernic RG28XX / PortMaster

Based on the complete, working PocketTracker 3 R5 source, including its audio, synth, MIDI, FM, MD/MNM, Open303, presets and effects.

## New controls

- **PHRASE / SELECT+A:** toggle between original NOTE/V/I/FX1/FX2/FX3 editor and a six-column **N1 / V / I / N2 / N3 / N4** chord editor. Up to four pitches sound on the same row with shared instrument, volume and FX. Chord notes are saved separately; selecting FX view never discards chords or existing effects. Grid selection, copy, cut, paste and delete work on chord columns. An authored OFF on N1 releases the track's voices.
- **CHAIN / SELECT+A:** select independent TSP loop length 00 (legacy) or 01..10 hexadecimal (1-16 positions). The transpose sequence's clock can cross phrase boundaries and repeat independently from phrase references.
- **CHAIN / SELECT+B:** choose transpose clock rate 1, 2, 4, 8, 16, 32 or 64 phrase rows per transpose step. For a five-step polymetric loop, set loop length **05** and rate **01**; for one TSP change per phrase, choose rate **10** (16 decimal).
- **INSTRUMENT / AUTOMATION:** YES phase-aligns instrument table start positions with song time. Tables use existing TIC rate, but retriggered notes start on the continuously advancing table row. Explicit THO wins. NO retains original R5 per-note table restart.
- **LIVE from editors:** while LIVE is enabled, START from CHAIN, PHRASE, TABLE, GROOVE, SCALE, INSTRUMENT, INST POOL or MODS launches/queues the remembered song cell rather than stopping the entire transport. R+START queues a stop on that track; after stopping the transport, R+START launches the remembered scene. Two presses promote queued launches/stops to the next phrase boundary, consistent with SONG LIVE.

## MIDI sound-module mode (four layers)

The MIDI screen now includes a scrolling performance section after TEST. Existing KEYS / VELOCITY remain unchanged for classic incoming-key mode.

- **MIDI MODE = CLASSIC**: retains R5/R6 input behavior (current instrument, 1-8 poly tracks from cursor position).
- **MIDI MODE = STACK**: each incoming note simultaneously triggers all selected layers; tracks are divided into independent polyphonic groups.
- **MIDI MODE = SPLIT**: keys below SPLIT AT use the lower half of layers and keys at or above it use the upper half. For four layers this means two layered instruments per keyboard zone.
- **MIDI MODE = CHANNEL**: each layer receives only the incoming channel specified in its Lx CH setting (1-16).
- **LAYERS = 1..4** sets how many instrument layers are active. **L1 INS..L4 INS** select instruments (CURSOR follows the last selected instrument). **L1 CH..L4 CH** select input channels. **SPLIT AT** edits the MIDI note number boundary (default 60).
- Up to eight incoming-key tracks are divided across layers. At four layers each gets two-note polyphony. Voice stealing is confined to its layer. All stacked note-offs release their own sounding voices, even when the cursor changes.
- Layer settings are saved to **settings.json**, not a .ptp project. A MIDI instrument routed to an external port uses that instrument's existing MIDI output channel setting.

This mode is implemented and covered by routing smoke tests, but has not yet been heard on an RG28XX; real-time audio performance and USB keyboard compatibility require on-device verification.

## Compatibility

R6 reads older R5 .ptp and .pti files. All new keys have defaults and are omitted when unused. Back up your projects; do not edit the only copy in a newer version then assume R5 can play its four-note chords.

R6 installs into `roms/ports/pockettracker3_r6/` and uses the separate launch script `PocketTracker 3 R6.sh`. R5 is not overwritten. To carry projects forward, copy your old `data/` contents into the R6 installation **while both applications are closed**.

## Validation status

PASS: C++ syntax checks for modified scheduler and editor code; release smoke test for existing AUDIO I/O, MOD12 and character FX; new R6 tests for chord data/clipboard, transpose loop clock, automation table phase; synthetic packaging/ELF identity test.

NOT YET VERIFIED: full host-engine build (an attempted build exceeded the local compile window), real ARM64 cross-compile and actual RG28XX hardware behaviour. **The source ZIP is not itself installable.** A successful GitHub Actions R6 run produces the real `pockettracker3_r6.zip` PortMaster installer.

Included `PocketTracker3_R5_Illustrated_Manual.pdf` is the original R5 reference for retained controls; use this document for R6 changes. The R5 manual has not been represented as an R6 manual.

# Credits & Acknowledgements

PocketTracker stands on a lot of excellent open-source work. Thank you to everyone below.

---

## Libraries

| Library | License | Use in PocketTracker |
|---|---|---|
| [Oboe](https://github.com/google/oboe) | Apache 2.0 | Low-latency Android audio stream |
| [DaisySP](https://github.com/electro-smith/DaisySP) | MIT **and** LGPL-2.1 (mixed — see note) | SVF filter, ReverbSc, DelayLine, Compressor, Limiter, BitCrush |
| [TinySoundFont](https://github.com/schellingb/TinySoundFont) | MIT | SF2 / SoundFont2 synthesizer (with per-channel rendering fork) |
| [KissFFT](https://github.com/mborgerding/kissfft) | BSD-3-Clause | FFT for spectrum analyzer and transient detection |
| [Soundpipe](https://github.com/PaulBatchelor/Soundpipe) (pareq stub) | MIT | Parametric EQ biquad |
| [skoomaDust](https://github.com/skoomabwoy/skoomaDust) | GPL-3.0 | Lo-fi effect chain; includes APComp FET compressor by Alain Paul (BSD-3-Clause) |
| [dr_libs](https://github.com/mackron/dr_libs) (dr_mp3 / dr_flac) | Public domain (MIT-0) | Native MP3 / FLAC decoding |
| [stb_vorbis](https://github.com/nothings/stb) | Public domain (MIT) | Native OGG Vorbis decoding |
| [libogg / libopus / opusfile](https://opus-codec.org/) | BSD-3-Clause | Native Opus decoding |
| [FAAD2](https://github.com/knik0/faad2) | GPL-2.0-or-later | AAC decoding — the audio track of `.m4a` and `.mp4` |
| [minimp4](https://github.com/lieff/minimp4) | CC0-1.0 (public domain) | ISO-BMFF container demuxing that feeds FAAD2 |
| [stb_image](https://github.com/nothings/stb) | Public domain (MIT) | Decoding theme, touch-skin and CRT-overlay PNGs |
| [stb_truetype](https://github.com/nothings/stb) | Public domain (MIT) | Rasterizing the touch skin's button-label glyphs |
| [Linux Biolinum](https://www.dafont.com/linux-biolinum.font) | SIL OFL 1.1 | The arrow glyphs on the touch control layout |
| [nlohmann/json](https://github.com/nlohmann/json) | MIT | Parsing `.ptp` / `.pti` project + instrument JSON |
| [SDL2](https://www.libsdl.org/) | zlib | Window, renderer, audio device, controller and keyboard input on every platform |
| [AndroidX Core-KTX](https://developer.android.com/jetpack/androidx/releases/core) | Apache 2.0 | Window-insets handling in the Android launcher activity |
| [AndroidX Core-SplashScreen](https://developer.android.com/jetpack/androidx/releases/core) | Apache 2.0 | Android 12+ splash-screen compatibility |

Each library keeps its own license. PocketTracker as a whole is distributed under GPL-3.0-or-later (see [`LICENSE`](LICENSE)).

**Full notices for everything compiled into PocketTracker — the audio engine and the SDL shell alike,
across all four packages — are in [`docs/licenses/THIRD-PARTY-NOTICES.md`](docs/licenses/THIRD-PARTY-NOTICES.md),**
which is the single source of truth and travels inside every release artifact.

**Oboe and the two AndroidX rows are Gradle-resolved rather than compiled from `native/`**, so they
exist only in the APK. Apache-2.0 §4(a) requires that a copy of the License reach anyone who receives
the binary, and naming it here does not do that — **the full Apache-2.0 text is in the notices file**,
which is why the notices cover them too despite not being engine code.

This file ships beside the notices in every artifact rather than only in the repo —
`assets/licenses/CREDITS.md` in the APK, and `licenses/CREDITS.md` in the Windows zip, the Linux
tarball and the PortMaster zip.

> **Note on DaisySP:** it is not uniformly MIT. Of the eight files PocketTracker compiles, five are
> MIT (`svf`, `overdrive`, `decimator`, `limiter`, `crossfade`) and **three are LGPL-2.1** —
> `compressor` (GRAME / Centre National de Creation Musicale), `balance` (Barry Vercoe, john ffitch,
> Gabriel Maldonado) and `reverbsc` (Sean Costello, Istvan Varga, Paul Batchelor) — because those
> descend from Csound and Faust rather than from Electrosmith's own code. LGPL-2.1 §3 permits
> applying the ordinary GPL v2 "or any later version", so they are distributed here under
> GPL-3.0-or-later along with the rest of the app. Per-file detail in the notices file above.

---

## DSP algorithm references

- **SOLA time-stretch** — Roucos & Wilgus (1985), Verhelst & Roelands (1993). The "Akai-cyclic" mode matches the algorithm used in Akai S950 / S1000 samplers; the characteristic grit on jungle breaks is intentional.
- **Biquad filter design** — Robert Bristow-Johnson, *Audio EQ Cookbook* (1994, rev. 2016).
- **OTT 3-band compressor** — parameters matched to the Xfer Records vitOTT plugin. Downward: −27 dBFS / 8:1; upward: −35 dBFS / 4:1; ~8 dB neutral zone.
- **Spectral flux transient detection** — Brossier et al., "Fast labelling of notes in music signals," ICASSP 2004.

---

## Contributors

- [@skoomabwoy](https://github.com/skoomabwoy) — authored the [skoomaDust](https://github.com/skoomabwoy/skoomaDust) lo-fi effect chain integrated into PocketTracker; ongoing technical advice throughout the project.

---

## Inspiration

- [Dirtywave M8](https://dirtywave.com/) — the portable tracker that proved the concept.
- [LGPT / Little Piggy Tracker](https://github.com/Mdashdotdashn/LittleGPTracker) — open-source tracker heritage.
- [LSDJ](https://www.littlesounddj.com/) — the Game Boy tracker that defined the form.

### LXR DSP experimental reference-derived engine (AIO12 R4)
Erica Synths LXR firmware source material (C) 2012-2026 Erica Synths,
GPL-3.0-only with additional NOTICE.md terms. Original wavetable values
and several DSP mathematical methods are incorporated, modified for
PocketTracker. This is not an official LXR or a verified accurate emulation.
See docs/LXR_DSP_REFERENCE_PORT.md.

## MD / MNM native machine voices (R5)

OP-XY MNMD contributors, MIT License. Source: https://github.com/mmockett/OP-XY-MNMD
Pinned revision: b43e9071015c6c7ec2cafa9ff8a060e9f43a3486.
The 33 synthesized MD and ten self-contained MNM voices are ported through a
PocketTracker host adapter, with output trims and sample-rate conversion.
No Elektron firmware, ROM samples, E12 or DigiPRO assets are included.
See native/vendor/mdmm/LICENSE and README.md for provenance and changes.

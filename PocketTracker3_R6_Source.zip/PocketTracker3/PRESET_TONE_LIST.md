# PocketTracker 3 R5 preset tones

**115 ready-to-load patches across all eleven native synthesis engines.** Sampler and Granular are excluded. The original R4 presets remain available alongside this bank.

On INSTRUMENT, choose PRESET LOAD and open Instruments. The filename prefix identifies its engine. A+START auditions the instrument at ROOT; try a lower or higher phrase note for basses and leads. GATE is already set for a useful initial note length. Use GATE 00 for held notes or to hear the full natural decay.

Preset_Tones_Audition.wav plays one patch each second in the order below. The time is the beginning of that patch. Output levels are balanced conservatively for layering; the audio is rendered by the actual engine with no sampler or granular source.

| Engine | Patches | Prefix |
|---|---:|---|
| Braids | 8 | BR |
| Rings | 8 | RG |
| Plaits | 8 | PL |
| DMG | 8 | DG |
| Handpan | 8 | HP |
| Drum Lite | 8 | DL |
| LXR DSP | 8 | LX |
| Open303 | 8 | O3 |
| FM Machines | 8 | CY |
| MD Machines | 33 | MD |
| MNM Machines | 10 | MN |

## Braids

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Warm Saw | bass / lead | C3 | 0:00 |
| Hollow Square | bass / pulse lead | C3 | 0:01 |
| Detuned Stack | poly synth | C4 | 0:02 |
| Vowel Lead | vocal lead | C4 | 0:03 |
| Glass Bell | bell / keys | C5 | 0:04 |
| Nylon Pluck | plucked keys | C4 | 0:05 |
| Air Flute | soft melodic lead | C5 | 0:06 |
| Dust Texture | pitched noise texture | C4 | 0:07 |

## Rings

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Bronze Keys | metal keys | C4 | 0:08 |
| Sympathetic Pluck | resonant string | C4 | 0:09 |
| Glass String | inharmonic pluck | C4 | 0:10 |
| FM Tines | electric piano | C4 | 0:11 |
| Quantized Harp | harp / arpeggio | C4 | 0:12 |
| Reverb String | ambient string | C4 | 0:13 |
| Low Resonator | deep mallet bass | C2 | 0:14 |
| Bright Chimes | high metallic arpeggio | C5 | 0:15 |

## Plaits

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Soft Analog | warm synth keys | C4 | 0:16 |
| Glass FM | FM keys | C4 | 0:17 |
| Scanning Keys | wavetable keys | C4 | 0:18 |
| Soft Chord | one-note chords | C3 | 0:19 |
| Vocal Formant | talking lead | C4 | 0:20 |
| Nylon String | plucked string | C4 | 0:21 |
| Metal Mallet | modal keys | C4 | 0:22 |
| Round Kick | percussion | C2 | 0:23 |

## DMG

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Pocket Bass | chip bass | C2 | 0:24 |
| Soft Triangle | rounded keys | C4 | 0:25 |
| Thin Pulse | chip lead | C4 | 0:26 |
| Soft Sine | clean chip keys | C5 | 0:27 |
| Folded Lead | bright digital lead | C4 | 0:28 |
| Wave Keys | wave scan keys | C4 | 0:29 |
| Pixel Pad | soft low-bit chord | C4 | 0:30 |
| Crunch Stab | short digital bass | C3 | 0:31 |

## Handpan

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Steel Pan | rounded melodic mallet | C4 | 0:32 |
| Soft Copper | soft sustained mallet | C4 | 0:33 |
| Wood Knock | woody percussion | C4 | 0:34 |
| Glass Bowl | bright bell | C5 | 0:35 |
| Temple Bell | long resonant bell | C4 | 0:36 |
| Muted Metal | short metallic keys | C4 | 0:37 |
| Deep Gong | low resonant percussion | C2 | 0:38 |
| Bright Tines | electric mallet | C5 | 0:39 |

## Drum Lite

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Round Kick | drum / percussion | C2 | 0:40 |
| Snap Snare | drum / percussion | D3 | 0:41 |
| Low Tom | drum / percussion | G2 | 0:42 |
| High Tom | drum / percussion | G3 | 0:43 |
| Closed Hat | drum / percussion | F#4 | 0:44 |
| Open Hat | drum / percussion | F#4 | 0:45 |
| Ride Cymbal | drum / percussion | C5 | 0:46 |
| Driven Kick | drum / percussion | C2 | 0:47 |

## LXR DSP

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Round Kick | drum / percussion | C2 | 0:48 |
| Snap Snare | drum / percussion | D3 | 0:49 |
| Low Tom | drum / percussion | G2 | 0:50 |
| High Tom | drum / percussion | G3 | 0:51 |
| Closed Hat | drum / percussion | F#4 | 0:52 |
| Open Hat | drum / percussion | F#4 | 0:53 |
| Ride Cymbal | drum / percussion | C5 | 0:54 |
| Driven Kick | drum / percussion | C2 | 0:55 |

## Open303

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Classic Acid | resonant acid bass | C2 | 0:56 |
| Round Sub | rounded sub bass | C2 | 0:57 |
| Square Rubber | hollow bass | C2 | 0:58 |
| Biting Lead | bright acid lead | C2 | 0:59 |
| Soft Pluck | warm short bass | C2 | 1:00 |
| Liquid Slide | legato bass | C2 | 1:01 |
| Resonant Hook | resonant sequence tone | C2 | 1:02 |
| Overdrive Bass | driven bass | C2 | 1:03 |

## FM Machines

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Deep Kick | percussion | C2 | 1:04 |
| Dry Snare | percussion | D3 | 1:05 |
| Metal Hat | percussion | F#4 | 1:06 |
| Wood Perc | percussion | C4 | 1:07 |
| FM Keys | FM keys / harmony | C4 | 1:08 |
| Soft Chord | FM keys / harmony | C3 | 1:09 |
| Glass Bell | FM keys / harmony | C5 | 1:10 |
| Low Gong | percussion | C2 | 1:11 |

## MD Machines

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Round Kick | TRX-BD percussion | C4 | 1:12 |
| Snap Snare | TRX-SD percussion | C4 | 1:13 |
| Analog Tom | TRX-XT percussion | C4 | 1:14 |
| Hand Clap | TRX-CP percussion | C4 | 1:15 |
| Wood Rim | TRX-RS percussion | C4 | 1:16 |
| Cowbell | TRX-CB percussion | C4 | 1:17 |
| Closed Hat | TRX-CH percussion | C4 | 1:18 |
| Open Hat | TRX-OH percussion | C4 | 1:19 |
| Ride Cymbal | TRX-CY percussion | C4 | 1:20 |
| Maraca | TRX-MA percussion | C4 | 1:21 |
| Twin Claves | TRX-CL percussion | C4 | 1:22 |
| Conga | TRX-XC percussion | C4 | 1:23 |
| Hard Kick | TRX-B2 percussion | C4 | 1:24 |
| FM Kick | EFM-BD percussion | C4 | 1:25 |
| FM Snare | EFM-SD percussion | C4 | 1:26 |
| FM Tom | EFM-XT percussion | C4 | 1:27 |
| FM Clap | EFM-CP percussion | C4 | 1:28 |
| FM Rim | EFM-RS percussion | C4 | 1:29 |
| FM Cowbell | EFM-CB percussion | C4 | 1:30 |
| FM Hat | EFM-HH percussion | C4 | 1:31 |
| FM Cymbal | EFM-CY percussion | C4 | 1:32 |
| Membrane Kick | PI-BD percussion | C4 | 1:33 |
| Membrane Snare | PI-SD percussion | C4 | 1:34 |
| Physical Tom | PI-MT percussion | C4 | 1:35 |
| Metal Plate | PI-ML percussion | C4 | 1:36 |
| Grain Maraca | PI-MA percussion | C4 | 1:37 |
| Physical Rim | PI-RS percussion | C4 | 1:38 |
| Physical Ride | PI-RC percussion | C4 | 1:39 |
| Physical Crash | PI-CC percussion | C4 | 1:40 |
| Physical Hat | PI-HH percussion | C4 | 1:41 |
| Sine Drum | GND-SN percussion | C4 | 1:42 |
| Noise Burst | GND-NS percussion | C4 | 1:43 |
| Impulse Click | GND-IM percussion | C4 | 1:44 |

## MNM Machines

| Preset | Use | Audition note | WAV time |
|---|---|---|---|
| Warm Saw | SWAVE-SAW synth | C4 | 1:45 |
| Animated Pulse | SWAVE-PULSE synth | C4 | 1:46 |
| Ensemble Chord | SWAVE-ENS synth | C4 | 1:47 |
| Chip Lead | SID-6581 synth | C4 | 1:48 |
| Static FM Keys | FM+STAT synth | C4 | 1:49 |
| Parallel FM Bell | FM+PAR synth | C4 | 1:50 |
| Dynamic FM Bass | FM+DYN synth | C4 | 1:51 |
| Vocal Lead | VO-6 synth | C4 | 1:52 |
| Pure Sine | GND-SIN synth | C4 | 1:53 |
| Red Noise | GND-NOIS synth | C4 | 1:54 |

## SoundFont and external MIDI

These routes use sounds from a loaded SoundFont or an attached MIDI instrument. They cannot provide self-contained native patches. With a General MIDI bank/device, these are useful starting programs (zero-based values shown):

| Tone | Program decimal | Program hex |
|---|---:|---|
| Acoustic Piano | 0 | 00 |
| Electric Piano | 4 | 04 |
| Jazz Organ | 16 | 10 |
| Finger Bass | 33 | 21 |
| Cello | 42 | 2A |
| String Ensemble | 48 | 30 |
| Flute | 73 | 49 |
| Soft Synth Pad | 89 | 59 |

For SoundFont, load the bank and choose its PATCH. For EXTERNAL, choose the MIDI port/channel and use PROG; a non-GM bank may assign different sounds. These program suggestions are not counted in the 115 native presets.

MD and MNM models are independent MIT-licensed approximations ported from OP-XY MNMD. No Elektron firmware, E12 samples or DigiPRO ROM waves are included.

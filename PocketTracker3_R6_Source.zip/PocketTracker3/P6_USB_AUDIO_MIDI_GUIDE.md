# PocketTracker 3 R5 - Roland P-6 USB audio and MIDI

## Connect the P-6

On the P-6, set AIRA Link to OFF, then turn it off and on again. Roland's menu
procedure is SHIFT + OCT+ (MENU), choose A.Lnk, ENTER, set OFF, EXIT twice, restart.
Use a USB data cable and the RG28XX OTG host port. The P-6 supports USB Audio
Class 2.0 and USB MIDI; no captured ROM, sample bank or firmware is needed here.

Roland's connection instructions:
https://static.roland.com/manuals/p-6/en-US/104364811123728523.html

## Choose audio directions independently

PROJECT > AUDIO I/O:

1. OUTPUT: choose the P-6 to hear PocketTracker through the P-6's output/headphones.
2. INPUT: choose the P-6 to capture its sound into PocketTracker.
3. Play a P-6 pad. The input meter should move before recording.

Linux/ALSA also exposes real PCM endpoints, with a card ID such as P6 and a PCM
number, when the kernel reports playback/capture. Try that P6 entry if the
ordinary SDL name is absent or refuses to open. Devices are saved by name and
refreshed on replug. A missing preferred input is shown OFF; it is not silently
replaced with another microphone. Choosing OFF closes the input monitor.

The output choice keeps the tracker session clock fixed, while SDL/ALSA handles
the USB endpoint's rate and format. Input accepts mono/stereo and converts native
PCM formats to float, then saves PCM16 WAV at the capture stream's rate. The
AUDIO page shows the stream rates/channels. Live input is metered, not passed
straight through to the output.

Roland confirms MIX IN is also sent over USB:
https://support.roland.com/hc/en-us/articles/29040602222491-P-6-Is-Audio-From-the-MIX-IN-Jack-Sent-to-the-Computer-via-USB

## Record straight into an instrument

1. Choose the Sampler or Granular instrument that should receive the take.
2. Move to AUDIO IN and press A. The row changes to STOP, with a red REC target,
   an elapsed timer, level meter and progress line. The input meter is live while
   idle too, so you can check the source first.
3. Press A on STOP to finish (or wait for the 30-second limit).
4. The unique TAKE WAV is saved in Samples and loaded into that original slot.
   Moving to another instrument while recording does not redirect the take.
5. Press A+START to audition. EDIT shows its waveform. The new source starts from
   the full sample window, without old slices/reverse/loops; ROOT is C4 and GATE
   00, so a previous short gate cannot hide the recording. Granular keeps its type, and its source-rate correction preserves pitch when
   capture and playback rates differ.

Start, disconnect, no-data, write and load errors appear on the instrument screen
as well as AUDIO. An unsuccessful take keeps the previous sample reference.
If the meter stays flat, check P-6 source levels, pad playback and its USB routing.
If the timer advances but no data arrives, stopping reports NO AUDIO DATA rather
than quietly claiming a useful recording.

## MIDI input and output

Audio device selection and MIDI port selection are independent. In PROJECT >
MIDI, choose the P-6 under OUTPUT and INPUT separately. The RX counter shows
received MIDI messages, including clock, so it proves MIDI data is arriving.

To sequence the P-6, use an EXTERNAL instrument and set its MIDI CH to match the
P-6's receive channel. Set PROG only when you want to change its sound. The MIDI
page's TEST sends C4 on channel 1; it will only test a device listening there.
PANIC sends note-offs if a note sticks.

For incoming notes, select the instrument you want to play and set KEYS to MONO
for the first test. Increase the live voice count afterwards if you want polyphony.
MIDI input does not carry audio: use the audio INPUT and recorder for that.
Name-based MIDI hotplug/reopen and same-port thru suppression are retained. A
port that is initially busy is retried after a short delay. Unplug/replug the cable if the OS has not re-enumerated both directions.

## Verification and device limits

Software tests exercise the production recorder, real SDL PCM conversion, USB-like
mono/stereo streams at 44.1/48 kHz, output callbacks and fixed session rate, saved
device names, replug/reorder, no-data/disconnect errors, WAV decode, immediate slot
attachment and actual Sampler/Granular playback. They do not certify a physical
P-6 or a particular Knulli kernel. The launcher log includes selected audio names,
PCM routes, stream formats and MIDI port diagnostics for a device-specific report.

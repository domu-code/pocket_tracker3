# PocketTracker 3 R5 validation

R5 adds native MD MACHINES (33 models) and MNM MACHINES (ten models), 18 model/slot
FX, 115 level-checked presets, and USB audio/recording fixes on the R4 foundation.
Old instrument identities and FX/controller values are retained.

## Software checks

- Full host DSP, polyphony, recording, schema, modulation, character FX, MIDI/UI
  and packaging suite. Contextual picker covers all fifteen instrument types.
- 43 new models sound at 44.1/48 kHz; every control endpoint produces finite,
  bounded output. Address/undefined-behaviour sanitizer check passes; leak checks
  are disabled because proc/ptrace access is unavailable in this environment.
- New engine integration: saved projects/presets, all model selectors, every slot
  mapping, phrase/table controls, gate/note-off, sample-position live edits and
  the actual contextual picker. Legacy seven-command FM integration retained.
- Audio session integration: saved P-6 names, input meter, visible errors,
  hotplug/reorder, stereo capture and immediate playable Sampler/Granular source
  attachment to the original slot. Full sample window, C4 root and GATE 00 are set.
  Both engines preserve 440-Hz pitch from a 44.1-kHz take at 48-kHz playback.
- Actual SDL format conversion and native WAV decoding under ARM64 execution:
  PCM16/PCM32/float, 44.1/48 kHz, mono/stereo; output callbacks and fixed session
  clock; AUTO input independent of the ALSA playback AUDIODEV; no-data/disconnect
  errors. The device API is simulated; SDL converters and native engine are real.
- MIDI USB ports retry after an initially busy open, with a three-second backoff;
  independent input/output names and same-port thru suppression are tested.
- 115 factory patches are canonical .pti files, rendered through the actual
  tracker engine, checked for silent/non-finite/clipped output and level-balanced.
- Actual ARM64 application, ELF/table verification, glibc floor at/below 2.31,
  system SDL linkage, and packaged headless smoke boot. Firmware/device USB and
  full-song CPU load still require a physical handheld test.
- Illustrated manual and companion tone catalogue: all 185 effect registry
  entries (184 commands plus empty), native UI illustrations, searchable text,
  text bounds and rendered-page review.

## Scope

MD/MNM are independent MIT-licensed OP-XY MNMD approximations, not Elektron ROM
emulation. E12, DigiPRO ROM waveforms, UW recording machines and original Elektron
firmware effects are not included. No proprietary assets ship. R4 FM MACHINES
remains its own six-model engine. MD/MNM share eight active voices within the
sixteen synth slots; actual RG28XX load is not certified by software emulation.

The source manifest, BUILD_INFO.json and kit checksums identify exact source and
binary bytes. Use the separate R5 launcher/folder while retaining your working R4
installation and data backup. P6_USB_AUDIO_MIDI_GUIDE.md includes Roland's AIRA
Link OFF / restart requirement and the independent audio/MIDI setup procedure.

# PocketTracker 3 R5 — Plaits

Choose TYPE=PLAITS. MODEL spans decimal 0–23 (FX PMD 00–17). HARMONICS, TIMBRE,
MORPH, DECAY and LPG COLOR use 00–FF. The original OUT/AUX feed the two channels
before tracker level, pan and sends. Projects and presets save these parameters.

R3's FX picker shows PMD, PHA, PTM and PMO for Plaits. PDC/PLG appear only for
models that use the LPG; they are hidden on models 2–4 and 19–23. Model 15 speech
keeps these controls because internal-envelope use depends on its patch settings.
Authored PMD changes before the cursor refine the picker context.

The actual original DSP, all 24 models, resources and MIT notices are bundled in
the source. No network fetch or temporary stand-in header is needed to build this
release. It runs internally at 48 kHz. See the illustrated manual for model names,
hex IDs, common voice/gate controls and every FX abbreviation. For current USB
routes, see USB_AUDIO_MIDI_GUIDE.md or PROJECT > AUDIO / MIDI.

# PocketTracker BR / DMG 4-BIT + HANDPAN POLY (experimental)

This branch extends the working Braids/Rings/Plaits/USB build. The seven existing instrument type identifiers are unchanged. The two new types are DMG (8) and HANDPAN (9); ProgramType values are appended as 7 and 8, with no existing synth effect code renumbered.

## New polyphony system

Both synths are real independent native voices rather than captured pitches inside a monophonic instrument.
- The shared existing 16-slot synthesis pool contains one independent DMG phase and filter, or one complete handpan modal body, for every triggered note.
- A new DMG or HANDPAN note does not automatically release the preceding note on its own tracker track.
- Free slots are used first; released/quiet voices are stolen only when the pool is full. Previous Braids, Rings, Plaits and granular track-level behaviour is preserved.
- Handpan bodies decay physically, even without explicit note-off. They retire when sufficiently quiet after the initial attack, with a 30-second maximum lifetime. A KIL/transport stop still ends voices.
- Maximum total polyphony across Braids/Rings/Plaits/DMG/HANDPAN/granular is 16 (shared pool); CPU and memory use increase with simultaneous modes.

## DMG instrument

16 individual wave-bank slots x 32 four-bit cells; bank data is stored in .pti/.ptp as 512 hexadecimal nibbles, not a file pointer.

- BANK WAVE (00-0F): selects editable bank. STEP (00-1F): selects one of its 32 cells. 4-BIT VALUE (0-F): paints the cell. These three controls provide the first, compact, tracker-friendly bank editor.
- BANK SCAN, WARP, FOLD, WRAP, WIDTH, BITS (1-4), SMOOTH (0/1), CUT4, RES4 are rendered independently for each note.
- Wave scan, warp, fold, wrap, width, bit depth, smoothing, cutoff and resonance have per-step FX commands, listed in the SYNTH FX picker.
- Default 16-bank collection contains saws, triangles, pulses, stairs and chip patterns. This is a software 4-bit wave channel, not cycle-exact Game Boy hardware.
- Because each note has its own oscillator phase and filter, overlapping note attacks do not interrupt previous notes.

## Handpan instrument

A lightweight handpan-inspired physically modelled synthesizer, using up to 18 individually damped resonant partials per note. Its ratios use the eighteen-partial HangGhost/handpan ideas from our earlier experiments.

- BODY MODEL (0-7) blends between handpan/steel-like mode relationships.
- MODES (4-18) trades spectral complexity for CPU budget; default 12.
- RESONANCE, STRIKE HARD, STRIKE POS, COUPLING, BODY TONE, STEREO are editable.
- MODE/DECAY/HARDNESS/POS/STEREO are captured on the note's attack; COUPLING and BODY TONE work on an already ringing note. The FX commands for onset parameters therefore apply at trigger or the next note, not by retuning an already struck resonator.
- Independent per-note modal banks allow chord intervals and sympathetic tails. This implementation is a compact native *adaptation*. It is not a byte-for-byte port of the complete HandpanModalSynth_v22 Processing instrument because its full `.pde` source was not available here. In particular the v22's 40-scale presets, 74 instrument presets and additional second-ring controls are not reproduced in this first integrated build. PocketTracker's own note/scale sequencing continues to work.

## Sound and persistence

Instrument presets (.pti) and full tracker projects (.ptp) store the parameters. Existing Braids/Rings/Plaits instrument and FX codes remain unchanged. These new instruments use the normal mixer, track fader, pan, reverb and delay paths.

The EXTERNAL instrument, ALSA USB MIDI output, and optional USB DAC audio output settings are preserved. USB gadget audio into a computer is **not** implemented.

## Verification

- Braids 47 and Rings 6 engine audio smoke tests: passed (44.1/48 kHz).
- DMG 8 + Handpan 8 concurrent voice smoke tests: finite and non-silent (44.1/48 kHz).
- DMG 512-cell bank and Handpan preset JSON round trips: passed.
- Thirty-two synth FX names, ranges, helper group and descriptions: passed.
- Modified C++ integration files compile with a **temporary stand-in Plaits API header**. The complete actual Plaits DSP + AArch64 cross-build must be run in GitHub Actions. The stand-in is never packaged.
- RG28XX performance, USB routing with external hardware and real device audio: not yet tested.

The GitHub workflow fetches the pinned official Mutable DSP source and produces build logs even when a cross-build fails. Leave the previously working Plaits source/build untouched until the updated device package runs.

# PocketTracker All-Engines Polyphony Update

This source is derived from the last DMG/Handpan/Plaits/USB checkpoint. It preserves the Mutable DSP, DMG and handpan integrations, FX picker and USB routing.

## Native polyphony

- Native synth pool: 16 simultaneous independent Braids, Rings, Plaits, DMG, Handpan and Granular voices in total.
- PCM sampler pool: 16 independent sample voices (formerly eight).
- No implicit mono kill on a new note for those pools. Explicit OFF, KIL, stop and track transitions retain their release/stop semantics.
- Both pools use `native/poly-allocator.h`: free first, then quiet releasing, then quiet held, oldest on ties; fixed stack/state, no heap allocations in the audio callback.
- Rings' post-note-off envelope is lengthened to approximately 1.4 seconds, with its own resonator feedback tail.
- Granular voices each own their own `GranularVoice` state/grain array.
- Sampler voices each own independent PCM pointers, playheads, table/FX state and envelopes.

## Present limits

- A tracker track's OFF, KIL and live KEY OFF events are still track-scoped rather than pitch-specific. Same-track notes overlap until one of those commands; it can release all that track's notes.
- External MIDI note-input routing uses eight track lanes: a MIDI chord therefore supports up to eight separately held notes through that router, even though synth and sampler voice pools each have 16 slots.
- SoundFont instruments use the original track/channel wrapper and are not migrated into this allocator; source-level polyphony for SoundFont remains a separate integration.
- Polyphonic Plaits, Braids, Rings and handpan simultaneously may exceed RG28XX real-time CPU budget. Try 4-8 sustained voices before testing the whole 16-slot limit.
- USB audio means playback to a DAC/interface if Linux/Knulli supports it. USB gadget audio (computer sees RG28XX as an audio interface) is not included.

## Checks run locally

- Braids/Rings and DMG/Handpan audio smoke tests, plus synth FX tests.
- `tests/run_poly_allocator_smoke.sh` validates selection under pool saturation.
- Host GCC `-fsyntax-only` checks on `native/engine-mix.cpp`, `native/audio-engine.cpp` and `native/engine-tables.cpp` against a temporary Plaits API stand-in. The stand-in is not included in this source or used in the GitHub build.

## Build

Run the updated `pockettracker-dmg-handpan.yml` on GitHub against the attached source ZIP. It downloads original pinned Plaits and performs a real C++ compilation and AArch64 cross-build. Do not replace the already-working Plaits executable on the handheld until this build succeeds and plays reliably.

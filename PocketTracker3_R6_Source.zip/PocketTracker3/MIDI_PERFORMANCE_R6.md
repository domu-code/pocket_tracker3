# PocketTracker 3 R6: MIDI sound-module mode

Open PROJECT > MIDI, then scroll below TEST. Use the existing edit gesture (A + D-pad) to change values. Values persist in `settings.json`, independently of projects.

| Row | Settings | Purpose |
|---|---|---|
| MIDI MODE | CLASSIC / STACK / SPLIT / CHANNEL | How keyboard messages are routed |
| LAYERS | 1-4 | How many instrument layers are active |
| SPLIT AT | 1-126 | Lowest MIDI note in the upper zone (default 60, middle C) |
| L1 INS - L4 INS | CURSOR, 01-128 | Instrument used by each layer |
| L1 CH - L4 CH | 01-16 | Incoming MIDI channel of each layer in CHANNEL mode |

**CLASSIC** retains the R5 live-key instrument selection and KEYS mono/poly track window.

**STACK** triggers every enabled layer when any incoming note arrives, regardless of its channel.

**SPLIT** divides the active layers into two zones. Keys below `SPLIT AT` trigger the first half; keys at and above it trigger the remaining layers. With four layers, each zone stacks two instruments. With three layers, the lower zone stacks L1 + L2 and the upper zone plays L3. `SPLIT AT = 60` means B3 and below go to the lower zone while C4 and above go to the upper zone.

**CHANNEL** maps incoming MIDI channels individually to layers using each `Lx CH` row, enabling external keyboards and multitimbral MIDI sequences to play instruments on separate channels. In this mode, the key range is unrestricted.

The engine exposes eight live-key tracks, partitioned among active performance layers. Two layers get four tracks each, four layers get two tracks each, providing independent note polyphony; a new note steals the oldest occupied track **within its own layer only**. Every note-off releases the key across all corresponding layers; MIDI CC 120 and 123 release channel-owned notes.

`Lx INS = CURSOR` means that layer follows the last selected instrument. Otherwise it keeps the selected instrument even when editing another screen. The existing instrument MIDI output channel decides where an instrument with external routing sends notes; `Lx CH` selects *incoming* keyboard channels only.

Older settings files default to CLASSIC and remain usable. R5 installations and song files are not overwritten. Avoid using the same track pool for a playing song and live keyboard without considering voice stealing. MIDI input and all engines must be tested on the actual RG28XX, as local smoke tests only validate event routing.

# Hear Tape / wow / flutter in PocketTracker 3 R5

1. PROJECT > LOAD > **FX_Tape_Listen.ptp**.
2. Return to PHRASE or SONG and press START. This is a held internal Open303 tone.
3. From a main page, hold R and press DOWN twice to reach EFFECTS.
4. In **TAPE / WANDR**, use **WET FF**, **DEPTH D0**, **RATE 70**, **DRIVE 20**.
5. Compare WET **00** (bypass) with **FF** (processed). Hold A while editing values.

All values above are hex. WET is the blend, DEPTH is pitch-movement amount, RATE is
speed. A brief drum hit is a poor wow/flutter listening source; a held note makes
the movement obvious. The comparison WAV plays four seconds dry, then four seconds
with Tape enabled using the production UI-to-audio path.

There is no other enable switch. Tape is an independent global master insert:
MASTER TYPE selects OTT/DUST, and REV/DEL are separate send effects. The Tape, Comb
and LoFi headers now show ON/OFF from their authored WET values. Phrase TWT/TRT/TDP
commands can override those values during playback without rewriting the page.
The listening project has no such overrides.

EXTERNAL instruments emit MIDI; their audio is outside PocketTracker and is not
processed by its master FX. Record that audio into a sample to process it inside
the app. USB input capture currently records samples; it is not an automatic
live-through effects channel.

The R3 WET control was reproduced in a full InputDispatcher + AudioEngine test and
was effective. This release adds clearer state labels and an audible test project;
it does not claim a reproduced hardware-only failure was fixed.

Other ready-made tests: **FX_LoFi_Listen.ptp** uses a strong bit/sample-hold sound;
**FX_Comb_Listen.ptp** uses short FM hits and a low trigger threshold. On Comb, WET
blends the return but **THR must be low enough for the input to trigger**. Try WET
C0, THR 08, FDBK B0, TUNE 60. A steady held note triggers once, while separated hits
re-arm and retrigger it.

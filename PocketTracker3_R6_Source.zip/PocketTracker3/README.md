# PocketTracker 3 R6

Native MD/MNM multi-model engines, contextual FX controls, 115 preset tones and
USB audio recording fixes. See [MD/MNM guide](MD_MNM_MACHINES_GUIDE.md),
[preset tone list](PRESET_TONE_LIST.md), [P-6 USB guide](P6_USB_AUDIO_MIDI_GUIDE.md)
and [validation](VALIDATION.md). The R5 PortMaster launcher uses its own folder.

# PocketTracker 3 Open303 — PT3 R2

Cumulative RG28XX/PortMaster build based on PocketTracker, retaining the existing
Braids, Rings, Plaits, sampler/granular, DMG, handpan, drum engines, MIDI, modulation
and character effects.

Read [POCKETTRACKER3_GUIDE.md](POCKETTRACKER3_GUIDE.md) for installation and controls,
and [VALIDATION.md](VALIDATION.md) for completed checks and hardware test limits.

Bundled dependency revisions are in DEPENDENCIES.json. The SDL build SDK omits
upstream test media and unrelated IDE projects. The runtime uses the handheld SDL2.

For GitHub, upload the intact PocketTracker3_Open303_Source.zip at the repository root and
place build-pockettracker3-open303.yml at .github/workflows/build-pockettracker3-open303.yml.

Original project documentation: [upstream README](docs/UPSTREAM_README.md).
Licences and original credits are retained in LICENSE, CREDITS.md and docs/licenses/.

Open303 controls and examples: see OPEN303_GUIDE.md.

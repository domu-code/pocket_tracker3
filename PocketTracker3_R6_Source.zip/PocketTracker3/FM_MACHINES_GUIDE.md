# FM MACHINES - PocketTracker 3 R5

Choose **INSTRUMENT > TYPE > FM MACHINES**, then MODEL:
00 KICK, 01 SNARE, 02 METAL, 03 PERC, 04 TONE, 05 CHORD.

This is an independent native macro-FM instrument, inspired by the six-machine
workflow of Model:Cycles. It contains no Elektron firmware or extracted algorithms.
Original Machinedrum/Monomachine firmware emulation is a separate future port.

| Instrument control | Tracker FX | Values |
| --- | --- | --- |
| MODEL | FMD | 00-05 |
| COLOR | FCL | 00-FF |
| SHAPE | FSH | 00-FF |
| SWEEP | FSW | 00-FF |
| CONTOUR | FCN | 00-FF |
| DECAY | FDC | 00-FF |
| PUNCH | FPN | 00-FF |

All seven work in PHRASE and TABLE and appear in the engine's **SYNTH** command menu. Hold A+UP on a phrase FX
**type**, navigate while keeping A held, release to select. A FMD on a note row
chooses its model before the voice starts. FX-only rows change sounding FM voices;
the next note starts from the saved instrument again. Each macro has a useful
mapping in each model, rather than offering ignored knobs.

COLOR maps ratios/noise/balance, SHAPE maps modulation depth (CHORD chooses one of
16 interval structures), SWEEP maps transient pitch or harmonic motion, CONTOUR
maps modulation decay and spectral damping/feedback. DECAY controls amplitude;
PUNCH adds attack emphasis. GATE can cut the note earlier: use **00** to hear the
full tail, or **GAT** for per-note duration. POLY permits overlaps within the global
8-FM-voice cap and shared 16-synth-voice pool. Common pitch/pan/send FX remain.

Use **FM_Machines_Demo.ptp**, which sequences all seven commands, or load one of the
six **FM_*.pti** presets. A+START auditions the current instrument. The supplied
software audio demo renders the actual tracker engine and this project.

FM tables use three independent TIC/HOP clocks and support the seven FM commands,
transpose/volume, PAN, FIN, PIT, REV, DEL, GAT and immediate KIL. Trigger, note-map,
octave-map and 200 Hz modes are available. They do not add sampler-only filtering
or the sampler/SoundFont modulation matrix to this engine.

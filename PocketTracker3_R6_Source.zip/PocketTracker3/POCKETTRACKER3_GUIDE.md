# PocketTracker 3 R5 — PortMaster

Install `pockettracker3_r5.zip` into your usual **ports** directory. Its root launcher
is **PocketTracker 3 R5.sh**, beside the **pockettracker3_r5/** directory. Launch it
and check **PT3 R5** on PROJECT. User data is in **pockettracker3_r5/data/**.
Copy earlier data into that folder while both apps are closed; retain a backup.

Read **PocketTracker3_R5_Illustrated_Manual.pdf** for the current complete user
reference. It is included beside the binary. The R3 change is the instrument/model
aware FX picker: hold A + UP on a phrase/table FX type, navigate while holding A,
release to choose. Shared commands remain visible. See `FX_PICKER_R3.md`.

All R2 engines remain: sampler, SoundFont, original Braids (47 models), Rings (6),
Plaits (24), granular, DMG, Handpan, Drum Lite, LXR DSP* and original Open303.
The twelve modulation slots target implemented sampler/SoundFont parameters.
PROJECT > AUDIO supports SDL output/input selection and 30-second WAV capture.
PROJECT > MIDI handles USB host MIDI ports exposed by the OS. The character FX
are global Tape, Comb and LoFi inserts, each bypassed when WET is 00.

A+D-pad edits (LEFT/RIGHT one, UP/DOWN sixteen or an octave), A+B clears,
R+D-pad changes pages, B+D-pad changes items, L+B selects, B copies, L+A pastes.
START plays/stops in ordinary transport; A+START auditions an instrument.

The source archive is self-contained, including Plaits and the SDL 2.0.18 link
SDK. The included workflow checks its exact SHA-256, builds the real ARM64 ELF at
the Ubuntu 20.04/glibc 2.31 floor and packages this isolated install. It links the
handheld's SDL dynamically. Software checks do not replace testing your USB
interface or full-song CPU load on the physical handheld.

R5 adds native **FM MACHINES** (Kick/Snare/Metal/Perc/Tone/Chord), with seven model/
macro FX available in the contextual picker and native FM tables. Read
FM_MACHINES_GUIDE.md. For Tape, load FX_Tape_Listen.ptp and see FX_LISTEN_GUIDE.md.
The Tape, Comb and LoFi section headers show their authored ON/OFF wet state.

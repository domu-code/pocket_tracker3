# Open303 — PocketTracker 3 R5

Select **INSTRUMENT > TYPE > OPEN303**. Set ROOT to C-2 for a low audition note.
A+START auditions the selected instrument. Use ordinary phrase notes to sequence it.

This instrument runs Robin Schmidt's original Open303 C++ DSP: its bandlimited
saw/square oscillator, four-times oversampled TeeBee filter in TB_303 mode, filter
and amplitude envelopes, accent response and pitch slew. It is controlled by
PocketTracker's sequencer; the embedded Open303 sequencer is disabled.

## Start with the included examples

PROJECT > LOAD opens **Open303_Acid_Demo.ptp**, a four-bar bassline with cutoff,
saw/square changes, accents and slides. The instrument preset browser also includes:

- **Open303_Classic_Saw.pti**
- **Open303_Square.pti**
- **Open303_Long_Slide.pti**
- **Open303_Resonant_Drive.pti**

## Instrument controls and tracker FX

Most values use 00–FF hexadecimal. The numeric ranges below describe their musical
mapping. Presets and projects save every parameter.

| Device label | FX | Range / action |
| --- | --- | --- |
| CUTOFF | OCT | 20 Hz–12 kHz, logarithmic |
| RESO | ORS | 0–100% resonance |
| ENV MD | OEM | 0–100% filter envelope modulation |
| ENV DC | ODC | Normal filter envelope decay, 30–3000 ms |
| ACCENT | OAC | Accent strength, 0–100% |
| WAVE | OWV | 00 saw, FF square, intermediate values blend |
| SLIDE | OTM | 1–1000 ms, logarithmic; default approximately 60 ms |
| LEGATO | OSL | 00 normal retrigger; 01 slide to this note in MONO |
| ATTACK | OAK | Normal filter envelope attack, 0.3–30 ms |
| ACC DC | OAD | Accented filter envelope decay, 30–3000 ms |
| AMP DC | OVD | Amplitude envelope decay, 16 ms–12 s |
| REL | ORL | Normal amplitude release, 0.5–1000 ms |
| DRIVE | ODR | Additional post-synth saturation; 00 bypass, FF +24 dB drive |
| FB HP | OHP | Filter feedback highpass, 20–1200 Hz |
| SUST | OSU | 00 decays away; FF full amplitude sustain |
| ACC MD | OAT | 00 normal; 01 force accent; 02 follow note velocity |

Open the phrase FX picker with A+UP on an FX type cell. The new commands are in
**SYNTH**, with descriptions. That group now scrolls as its cursor moves, keeping
the descriptions and group headings on screen.

## Accents

ACC MODE defaults to VELOCITY. MIDI velocities 100–127 trigger the original accent
path; lower velocities trigger normal notes. In the tracker volume column these
are hexadecimal **64–7F** for an accent, **00–63** for normal. For example, **4C** is
a normal hit and **76** is an accented hit.

The native accent affects the filter envelope and amplitude response. ACCENT sets
its strength; ENV DECAY controls normal notes, while ACC DECAY controls accented
notes. Open303's accented amplitude release remains its native fixed 50 ms;
RELEASE controls normal notes. OAT lets you explicitly choose normal or accent
when you want the tracker volume and accent decision to be independent.

## Slides and ties

1. Keep VOICE on MONO.
2. Use a gate long enough to overlap the following note. GATE **00** holds until
   OFF, a replacement note or KIL; **18** is 24 tracker ticks, or two ordinary steps.
3. Put **OSL 01 on the destination note** to slide into it. The existing voice and
   oscillator continue; its filter and amplitude envelopes are not retriggered.
4. Put OSL 00 on a destination note to retrigger normally. A same-pitch OSL 01 note
   acts as a tie. An OFF or an expired gate ends the overlap.

LEGATO on in the instrument makes overlapping MONO notes slide by default. OSL
overrides that decision for its note. SLIDE TIME / OTM sets the upstream pitch-slew
time. Sliding does not add octave jumps.

## Polyphony and effects

MONO is the default, with an independent monophonic line on each tracker lane.
POLY gives overlapping Open303 voices with separate filter and envelope state;
there is a global four-voice Open303 limit to bound CPU. Slide is a MONO operation.
Gate, volume, pan, pitch commands and the existing delay/reverb sends remain available.
Use the master Tape, LoFi and Comb effects for additional processing.

## Source and integration

Upstream: https://github.com/RobinSchmidt/Open303

Revision: `313bf0d9ade7c1dcb6b3a74f5ea1780a29d70074`.

Original MIT licence and attribution ship with the source and compiled port.
Portability changes add standard headers, make UINT32 truly 32-bit on LP64 Linux,
and provide the four padding samples that the upstream wavetable initialization
already writes. Original upstream file hashes are retained alongside the vendor
source. Synthesis algorithms are the original implementation.

The adapter prepares wavetables and voice memory before playback. It calls the
original trigger/slide methods directly, avoiding the upstream MIDI list's heap
allocation in the audio callback. The host adds fixed voice allocation, parameter
mapping, post-synth drive, tracker FX, save/load and MIDI/tracker routing.

The installer launches as **PocketTracker 3 R5**, stores data in
`ports/pockettracker3_r5/data/`, and shows **PT3 R5** on PROJECT.

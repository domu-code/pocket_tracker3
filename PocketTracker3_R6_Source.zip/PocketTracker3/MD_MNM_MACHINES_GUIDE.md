# PocketTracker 3 R5 - MD / MNM machines

Choose INSTRUMENT > TYPE > MD MACHINES or MNM MACHINES. MODEL shows a hexadecimal
number and the machine name. MD has 33 synthesized percussion models; MNM has ten
self-contained synth models. They are independent approximations using the
MIT-licensed OP-XY MNMD voice modules, not original Elektron firmware emulation.
No ROM file, SysEx dump or external sound library is required.

## Controls and FX

The eight controls keep the selected model's actual names: PTCH, DEC, UNIL,
1FRQ, VOC1 and so on. An unused slot shows --. Changing MODEL loads that model's
usable defaults. Save a separate preset/instrument to keep another model's patch.
The bank supplies a named starting sound for every model.

| Engine | Model FX | Parameter slots | Range |
|---|---|---|---|
| MD MACHINES | MDM | MD1 MD2 MD3 MD4 MD5 MD6 MD7 MD8 | Model 00-20; slots 00-7F |
| MNM MACHINES | MNM | MN1 MN2 MN3 MN4 MN5 MN6 MN7 MN8 | Model 00-09; slots 00-7F |

On a phrase/table FX type field, hold A and press UP, then choose SYNTH. The menu
shows MODEL and only the parameter slots present on the current model. Highlight
a slot to see the model-specific parameter name. Model FX earlier in the phrase
or table update this context. Shared note, track, global and MIDI groups remain.

MODEL is applied before that note starts; same-step slot FX then override its
selected defaults. Later FX-only rows change the sounding voice. Slot overrides
remain for that voice; the next note reloads its saved instrument. MODEL changes
reset the selected algorithm's state at the next internal DSP block. Slot changes
and live pitch reach the 64-frame/44.1-kHz native block boundary (about 1.5 ms),
then sample-rate conversion maintains the pitch at 44.1/48 kHz device rates.
Per-model output trims balance levels for PocketTracker, retaining bounded output.

All 18 new FX work in phrase and table columns. Tables retain the FM engine's
three independent TIC/HOP clocks, transpose, volume, PAN, FIN, PIT, REV, DEL, GAT
and immediate KIL 00. General sampler modulation/filter commands keep their
existing routing; they do not become new filters inside these synth voices.

MONO/POLY, gate time, tuning, pitch, pan and reverb/delay sends remain available.
MD/MNM share at most eight active voices within the overall sixteen synth slots.
A closed TRX hat chokes an open TRX hat through their shared engine context.
MNM models play chromatically. MD presets are voiced at C4 (MIDI 60); moving the
phrase note also transposes them. A+START uses the preset's ROOT for auditioning.

## MD models

| Model hex | Machine | Slots 1 to 8 (dash means unused) |
|---|---|---|
| 00 | TRX-BD | PTCH, DEC, RAMP, RDEC, STRT, NOIS, HARM, CLIP |
| 01 | TRX-SD | PTCH, DEC, BUMP, BENV, SNAP, TONE, TUNE, CLIP |
| 02 | TRX-XT | PTCH, DEC, RAMP, RDEC, DAMP, DIST, DTYP, -- |
| 03 | TRX-CP | CLPY, TONE, HARD, RICH, RATE, ROOM, RSIZ, RTUN |
| 04 | TRX-RS | PTCH, DEC, DIST, --, --, --, --, -- |
| 05 | TRX-CB | PTCH, DEC, ENH, DAMP, TONE, BUMP, --, -- |
| 06 | TRX-CH | GAP, DEC, HPF, LPF, MTAL, --, --, -- |
| 07 | TRX-OH | GAP, DEC, HPF, LPF, MTAL, --, --, -- |
| 08 | TRX-CY | RICH, DEC, TOP, TTUN, SIZE, PEAK, --, -- |
| 09 | TRX-MA | ATT, SUS, REV, DAMP, RATL, RTYP, TONE, HARD |
| 0A | TRX-CL | PTCH, DEC, DUAL, ENH, TUNE, CLIC, --, -- |
| 0B | TRX-XC | PTCH, DEC, RAMP, RDEC, DAMP, DIST, DTYP, -- |
| 0C | TRX-B2 | PTCH, DEC, RAMP, HOLD, TICK, NOIS, DIRT, DIST |
| 0D | EFM-BD | PTCH, DEC, RAMP, RDEC, MOD, MFRQ, MDEC, MFB |
| 0E | EFM-SD | PTCH, DEC, NOIS, NDEC, MOD, MFRQ, MDEC, HPF |
| 0F | EFM-XT | PTCH, DEC, RAMP, RDEC, MOD, MFRQ, MDEC, CLIC |
| 10 | EFM-CP | PTCH, DEC, CLPS, CDEC, MOD, MFRQ, MDEC, HPF |
| 11 | EFM-RS | PTCH, DEC, MOD, HPF, SNAR, SPTC, SDEC, SMOD |
| 12 | EFM-CB | PTCH, DEC, SNAP, FB, MOD, MFRQ, MDEC, -- |
| 13 | EFM-HH | PTCH, DEC, TREM, TFRQ, MOD, MFRQ, MDEC, FB |
| 14 | EFM-CY | PTCH, DEC, FB, HPF, MOD, MFRQ, MDEC, -- |
| 15 | PI-BD | PTCH, DEC, HARD, HAMR, TENS, DAMP, --, -- |
| 16 | PI-SD | PTCH, DEC, HARD, RING, TENS, RVOL, RDEC, -- |
| 17 | PI-MT | PTCH, DEC, HARD, HAMR, TUNE, DAMP, SIZE, POS |
| 18 | PI-ML | PTCH, DEC, HARD, TENS, --, --, --, -- |
| 19 | PI-MA | GRNS, DEC, GLEN, --, SIZE, HARD, --, -- |
| 1A | PI-RS | PTCH, DEC, HARD, RING, RVOL, RDEC, --, -- |
| 1B | PI-RC | PTCH, DEC, HARD, RING, AG, AU, BR, GRAB |
| 1C | PI-CC | PTCH, DEC, HARD, RING, AG, AU, BR, GRAB |
| 1D | PI-HH | PTCH, DEC, CLSN, RING, AG, AU, BR, CLOS |
| 1E | GND-SN | PTCH, DEC, RAMP, RDEC, --, --, --, -- |
| 1F | GND-NS | DEC, --, --, --, --, --, --, -- |
| 20 | GND-IM | UP, UVAL, DOWN, DVAL, --, --, --, -- |

## MNM models

| Model hex | Machine | Slots 1 to 8 (dash means unused) |
|---|---|---|
| 00 | SWAVE-SAW | UNIL, UNIW, UNIX, --, SUBX, SUB1, SUB2, TUNE |
| 01 | SWAVE-PULSE | UNIL, UNIW, SUB1, SUB2, PW, PWAD, PWRS, TUNE |
| 02 | SWAVE-ENS | PCH2, PCH3, PCH4, WAVE, PW, CHRL, CHRW, TUNE |
| 03 | SID-6581 | PW, PWAD, PWRS, WAVE, MOD, MSRC, MFRQ, TUNE |
| 04 | FM+STAT | 1FRQ, 1FIN, 1ENV, 1FB, 2FRQ, 2VOL, TONE, TUNE |
| 05 | FM+PAR | 1FRQ, 1ENV, 2FRQ, 2ENV, 3FRQ, 3ENV, TONE, TUNE |
| 06 | FM+DYN | 1FRQ, 1FEN, 1VOL, 1VEN, 2FRQ, 2ENV, 2FB, TUNE |
| 07 | VO-6 | VOC1, VOC2, V-SW, VOIC, CONS, CLEN, CVOL, TUNE |
| 08 | GND-SIN | --, --, --, --, --, --, --, TUNE |
| 09 | GND-NOIS | ST, RED, STON, --, --, --, --, TUNE |

## Start with music

Load MD_Machines_Demo.ptp or MNM_Machines_Demo.ptp from Projects and press START.
MD_*.pti and MN_*.pti in Instruments cover every new model. PRESET_TONE_LIST.md
lists all 115 native presets and their audible preview times.

E12, DigiPRO, UW recording machines and original Elektron master/track-effect
firmware are not included. Use PocketTracker's sampler and existing effects for
sample playback and processing. The original FM MACHINES engine remains a
separate six-model instrument.

Source and MIT licence: https://github.com/mmockett/OP-XY-MNMD
Pinned revision: b43e9071015c6c7ec2cafa9ff8a060e9f43a3486.

# PocketTracker 3 R5 — USB audio and MIDI

Open **PROJECT > AUDIO**. OUTPUT selects SYSTEM or a detected SDL device; INPUT
selects OFF, AUTO or a detected capture device. Refresh the list after plugging
hardware in. RECORD START/STOP captures up to 30 seconds into a WAV sample for the
selected instrument. The sampler/granular AUDIO IN action uses the same recorder.

Open **PROJECT > MIDI**. Select input/output ports exposed by ALSA. KEYS chooses
MONO or live polyphony over 2–8 tracker tracks; VELOCITY controls key dynamics.
The last-selected instrument receives incoming notes; live keys audition rather
than writing phrase data. EXTERNAL instruments set output channel, bank, program,
note length, pitch-bend range and four CC slots. PANIC releases notes; TEST sends
C-4 on channel 1. Outgoing clock/transport is supported; incoming sync is not.

These are USB **host-mode** routes: Linux/CFW must recognise the interface and the
handheld must supply host/OTG connectivity. A powered hub may be needed. This does
not implement USB gadget audio, where a computer sees the handheld as a soundcard.

The optional legacy `data/audio_device.txt` launcher override can select an ALSA
identifier before startup. Remove it when returning to default device routing.
The AUDIO I/O page is the current normal device-selection interface.
